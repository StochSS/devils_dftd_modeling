import os
import sys
sys.path.insert(1, "/stochss")

import numpy
import pandas

import gillespy2

from stochss.handlers.util.stochss_model import StochSSModel

class DevilsDFTD2StageInfection():
    dirname = os.path.dirname(__file__)
    
    def __init__(self, interventions=None, devil_fitting=False):
        if interventions is None:
            if devil_fitting:
                path = "1-Devils-Parameter_Fitting.wkgp/1-Devils-Parameter_Fitting.mdl"
            else:
                path = "2-Devils_DFTD-Parameter_Fitting.wkgp/2-Devils_DFTD-Parameter_Fitting.mdl"
        else:
            if not isinstance(interventions, list):
                interventions = [interventions]
            if 'vaccination' in interventions:
                if 'culling' in interventions:
                    path = "7-Devils_DFTD-Vaccination_Culling.wkgp/7-Devils_DFTD-Vaccination_Culling.mdl"
                else:
                    path = "6-Devils_DFTD-Vaccination.wkgp/6-Devils_DFTD-Vaccination.mdl"
            elif 'culling' in interventions:
                path = "5-Devils_DFTD-Culling.wkgp/5-Devils_DFTD-Culling.mdl"
            elif 'immunity' in interventions:
                path = "4-Devils_DFTD-Immunity.wkgp/4-Devils_DFTD-Immunity.mdl"
            else:
                path = "3-Devils_DFTD-No_Intervention.wkgp/3-Devils_DFTD-No_Intervention.mdl"
        self.model = StochSSModel(path=os.path.join(self.dirname, path)).convert_to_gillespy2()
        pop_data = pandas.read_csv('./Devils_Dataset__Population_1985-2020.csv')
        self.devil_pop = numpy.array(pop_data['Population'].iloc[:].values)
        
    def __get_total_devils(self, traj):
        species = ["Juvenile", "Susceptible"]
        if "Exposed" in traj:
            species.extend(["Exposed", "Infected", "Diseased"])
        if "Vaccinated" in traj:
            species.append("Vaccinated")
        return sum([traj[key][-1] for key in species])

    def calculate_distance(self, results):
        '''return mean/stddev of L2 norm distance'''
        obs = numpy.vstack([self.devil_pop]).reshape(1, 1, -1)

        dists = numpy.zeros(len(results))
        for ndx, traj in enumerate(results):
            dists[ndx] = numpy.linalg.norm(traj['Devils'] - obs[0][0], 2)
        return numpy.average(dists), numpy.std(dists)

    def run(self, num_sims=1, **kwargs):
        ret_traj = []
        while len(ret_traj) < num_sims:
            kwargs['number_of_trajectories'] = num_sims - len(ret_traj)
            results = self.model.run(**kwargs)
            for traj in results:
                accepted = True
                if self.__get_total_devils(traj=traj) <= 0:
                    accepted = False
                elif "Infected" in traj and traj['Infected'][300] <= 0:
                    accepted = False
                if accepted:
                    ret_traj.append(traj)
            print(f"{len(ret_traj)} accepted trajectories")
        return gillespy2.Results(ret_traj)
