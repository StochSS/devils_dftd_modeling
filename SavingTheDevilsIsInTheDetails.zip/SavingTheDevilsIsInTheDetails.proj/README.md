To reproduce this work see the "Notes" for each model and proceed in the following order:
          1) 1-Devils-Parameter_Fitting.mdl
          2) 2-Devils_DFTD-Parameter_Fitting.mdl
          3) 3-Devils_DFTD-No_Intervention.mdl
          4) 4-Devils_DFTD-Immunity.mdl
          5) 5-Devils_DFTD-Culling.mdl
          6) 6-Devils_DFTD-Vaccination.mdl
          7) 7-Devils_DFTD-Vaccination_Culling.mdl